#include"ICGVisitor.h"
#include<fstream>
#include<iostream>

using namespace std;

ICGVisitor::ICGVisitor(ofstream& out, const string& printLibPath)
    : codeOut(out), printProcLibPath(printLibPath), symbolTable(30){
    labelCount = 1;
    currentLocalOffset = 0;
    currentFuncExitLabel = "";
    currentFuncName = "";
    inDataSegment = false;
    inCodeSegment = false;

    codeOut<<"format ELF executable 3\n";
    codeOut<<"entry main\n";
    codeOut.flush();
}

antlrcpp::Any ICGVisitor::visitStartRule(CSubsetParser::StartRuleContext *ctx){
    visit(ctx->program());

    codeOut<<";-------------------------------\n";
    codeOut<<";         print library         \n";
    codeOut<<";-------------------------------\n";
    ifstream libFile(printProcLibPath);
    if(libFile.is_open()){
        string line;
        while(getline(libFile, line)){
            codeOut<<line<<"\n";
        }
        libFile.close();
    } else{
        codeOut<<"print_number:\n"
               <<"\tpush eax\n\tpush ebx\n\tpush ecx\n\tpush edx\n\tpush esi\n\tpush edi\n"
               <<"\tsub esp, 32\n\ttest eax, eax\n\tjns .positive\n"
               <<"\tpush eax\n\tsub esp, 1\n\tmov byte [esp], '-'\n"
               <<"\tmov eax, 4\n\tmov ebx, 1\n\tmov ecx, esp\n\tmov edx, 1\n\tint 0x80\n"
               <<"\tadd esp, 1\n\tpop eax\n\tneg eax\n"
               <<".positive:\n"
               <<"\tmov ebx, 10\n\tlea esi, [esp + 31]\n\tmov byte [esi], 10\n\tdec esi\n"
               <<".convert:\n"
               <<"\txor edx, edx\n\tdiv ebx\n\tadd dl, '0'\n\tmov [esi], dl\n\tdec esi\n"
               <<"\ttest eax, eax\n\tjnz .convert\n\tinc esi\n\tlea edx, [esp + 32]\n\tsub edx, esi\n"
               <<"\tmov eax, 4\n\tmov ebx, 1\n\tmov ecx, esi\n\tint 0x80\n\tadd esp, 32\n"
               <<"\tpop edi\n\tpop esi\n\tpop edx\n\tpop ecx\n\tpop ebx\n\tpop eax\n\tret\n";
    }
    codeOut<<";-------------------------------\n";
    codeOut.flush();

    return std::any();
}

antlrcpp::Any ICGVisitor::visitProgramMultiple(CSubsetParser::ProgramMultipleContext *ctx){
    visit(ctx->program());
    visit(ctx->unit());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitProgramSingle(CSubsetParser::ProgramSingleContext *ctx){
    visit(ctx->unit());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitUnitVarDecl(CSubsetParser::UnitVarDeclContext *ctx){
    if(!inDataSegment){
        inDataSegment = true;
        codeOut<<"segment readable writeable\n";
        codeOut.flush();
    }
    visit(ctx->var_declaration());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitUnitFuncDecl(CSubsetParser::UnitFuncDeclContext *ctx){
    visit(ctx->func_declaration());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitUnitFuncDef(CSubsetParser::UnitFuncDefContext *ctx){
    visit(ctx->func_definition());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFuncDeclWithParams(CSubsetParser::FuncDeclWithParamsContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFuncDeclNoParams(CSubsetParser::FuncDeclNoParamsContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFuncDefWithParams(CSubsetParser::FuncDefWithParamsContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFuncDefNoParams(CSubsetParser::FuncDefNoParamsContext *ctx){
    if(!inCodeSegment){
        inCodeSegment = true;
        codeOut<<"segment readable executable\n";
        codeOut.flush();
    }

    string funcName = ctx->ID()->getText();
    currentFuncName = funcName;
    currentLocalOffset = 0;
    currentFuncExitLabel = newLabel();

    codeOut<<funcName<<":\n";
    codeOut<<"\tPUSH EBP\n";
    codeOut<<"\tMOV EBP, ESP\n";
    codeOut.flush();

    symbolTable.enterScope();

    visit(ctx->compound_statement());

    codeOut<<currentFuncExitLabel<<":\n";
    codeOut<<"\tADD ESP, "<<currentLocalOffset<<"\n";
    codeOut<<"\tPOP EBP\n";

    if(funcName == "main"){
        codeOut<<"\tMOV EAX, 1\n";
        codeOut<<"\tXOR EBX, EBX\n";
        codeOut<<"\tINT 0x80\n";
        codeOut<<"\tPOP EBP\n";
        codeOut<<"\tRET\n";
    } else{
        codeOut<<"\tRET\n";
    }
    codeOut.flush();

    symbolTable.exitScope();
    return std::any();
}

antlrcpp::Any ICGVisitor::visitParamSingleUnnamed(CSubsetParser::ParamSingleUnnamedContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitParamListUnnamed(CSubsetParser::ParamListUnnamedContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitParamSingleNamed(CSubsetParser::ParamSingleNamedContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitParamListNamed(CSubsetParser::ParamListNamedContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitCompoundWithStmts(CSubsetParser::CompoundWithStmtsContext *ctx){
    visit(ctx->statements());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitCompoundEmpty(CSubsetParser::CompoundEmptyContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitVarDecl(CSubsetParser::VarDeclContext *ctx){
    visit(ctx->declaration_list());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitTypeInt(CSubsetParser::TypeIntContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitTypeFloat(CSubsetParser::TypeFloatContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitTypeVoid(CSubsetParser::TypeVoidContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitDeclListSingle(CSubsetParser::DeclListSingleContext *ctx){
    string varName = ctx->ID()->getText();
    if(symbolTable.isRootScope()){
        if(!inDataSegment){
            inDataSegment = true;
            codeOut<<"segment readable writeable\n";
        }
        codeOut<<"\t"<<varName<<" dd 1 DUP (0)\n";
        codeOut.flush();

        SymbolInfo* sym = new SymbolInfo(varName, "ID");
        sym->setIsGlobal(true);
        sym->setVarType("int");
        symbolTable.insert(sym);
    } else{
        currentLocalOffset += 4;
        SymbolInfo* sym = new SymbolInfo(varName, "ID");
        sym->setIsGlobal(false);
        sym->setStackOffset(currentLocalOffset);
        sym->setVarType("int");
        symbolTable.insert(sym);

        codeOut<<"\tSUB ESP, 4\n";
        codeOut.flush();
    }
    return std::any();
}

antlrcpp::Any ICGVisitor::visitDeclListMultiple(CSubsetParser::DeclListMultipleContext *ctx){
    visit(ctx->declaration_list());
    string varName = ctx->ID()->getText();
    if(symbolTable.isRootScope()){
        if(!inDataSegment){
            inDataSegment = true;
            codeOut<<"segment readable writeable\n";
        }
        codeOut<<"\t"<<varName<<" dd 1 DUP (0)\n";
        codeOut.flush();

        SymbolInfo* sym = new SymbolInfo(varName, "ID");
        sym->setIsGlobal(true);
        sym->setVarType("int");
        symbolTable.insert(sym);
    } else{
        currentLocalOffset += 4;
        SymbolInfo* sym = new SymbolInfo(varName, "ID");
        sym->setIsGlobal(false);
        sym->setStackOffset(currentLocalOffset);
        sym->setVarType("int");
        symbolTable.insert(sym);

        codeOut<<"\tSUB ESP, 4\n";
        codeOut.flush();
    }
    return std::any();
}

antlrcpp::Any ICGVisitor::visitDeclListSingleArr(CSubsetParser::DeclListSingleArrContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitDeclListMultipleArr(CSubsetParser::DeclListMultipleArrContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtsSingle(CSubsetParser::StmtsSingleContext *ctx){
    visit(ctx->statement());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtsMultiple(CSubsetParser::StmtsMultipleContext *ctx){
    visit(ctx->statements());
    visit(ctx->statement());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtVarDecl(CSubsetParser::StmtVarDeclContext *ctx){
    visit(ctx->var_declaration());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtExpr(CSubsetParser::StmtExprContext *ctx){
    emitLabel(newLabel());
    visit(ctx->expression_statement());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtCompound(CSubsetParser::StmtCompoundContext *ctx){
    symbolTable.enterScope();
    visit(ctx->compound_statement());
    symbolTable.exitScope();
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtFor(CSubsetParser::StmtForContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtIfElse(CSubsetParser::StmtIfElseContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtIf(CSubsetParser::StmtIfContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtWhile(CSubsetParser::StmtWhileContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtPrintln(CSubsetParser::StmtPrintlnContext *ctx){
    emitLabel(newLabel());
    string id = ctx->ID()->getText();
    SymbolInfo* sym = symbolTable.lookUp(id);
    int line = ctx->getStart()->getLine();
    if(sym != nullptr){
        emitInstruction("PUSH EAX");
        emitInstruction("MOV EAX, " + sym->getAsmOperand(), line);
        emitInstruction("CALL print_number");
        emitInstruction("POP EAX");
    }
    return std::any();
}

antlrcpp::Any ICGVisitor::visitStmtReturn(CSubsetParser::StmtReturnContext *ctx){
    emitLabel(newLabel());
    int line = ctx->getStart()->getLine();
    visit(ctx->expression());
    emitInstruction("JMP " + currentFuncExitLabel, line);
    return std::any();
}

antlrcpp::Any ICGVisitor::visitExprStmtEmpty(CSubsetParser::ExprStmtEmptyContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitExprStmtExpr(CSubsetParser::ExprStmtExprContext *ctx){
    visit(ctx->expression());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitVarSimple(CSubsetParser::VarSimpleContext *ctx){
    string varName = ctx->ID()->getText();
    SymbolInfo* sym = symbolTable.lookUp(varName);
    int line = ctx->getStart()->getLine();
    if(sym != nullptr){
        emitInstruction("MOV EAX, " + sym->getAsmOperand(), line);
    }
    return std::any();
}

antlrcpp::Any ICGVisitor::visitVarArray(CSubsetParser::VarArrayContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitExprLogic(CSubsetParser::ExprLogicContext *ctx){
    visit(ctx->logic_expression());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitExprAssign(CSubsetParser::ExprAssignContext *ctx){
    int line = ctx->getStart()->getLine();
    visit(ctx->logic_expression());

    string varName = ctx->variable()->getText();
    SymbolInfo* sym = symbolTable.lookUp(varName);
    if(sym != nullptr){
        emitInstruction("MOV " + sym->getAsmOperand() + ", EAX", line);
        emitInstruction("PUSH EAX");
        emitInstruction("POP EAX");
    }
    return std::any();
}

antlrcpp::Any ICGVisitor::visitLogicExprRel(CSubsetParser::LogicExprRelContext *ctx){
    visit(ctx->rel_expression());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitLogicExprOp(CSubsetParser::LogicExprOpContext *ctx){
    string logicOp = ctx->LOGICOP()->getText();
    int line = ctx->getStart()->getLine();

    if(logicOp == "||"){
        string lTrue = newLabel();
        string lNext = newLabel();
        string lFalse = newLabel();
        string lEnd = newLabel();

        visit(ctx->rel_expression(0));
        emitInstruction("CMP EAX, 0", line);
        emitInstruction("JNE " + lTrue);
        emitInstruction("JMP " + lNext);

        emitLabel(lNext);
        visit(ctx->rel_expression(1));
        emitInstruction("CMP EAX, 0");
        emitInstruction("JNE " + lTrue);
        emitInstruction("JMP " + lFalse);

        emitLabel(lTrue);
        emitInstruction("MOV EAX, 1", line);
        emitInstruction("JMP " + lEnd);

        emitLabel(lFalse);
        emitInstruction("MOV EAX, 0");

        emitLabel(lEnd);
    } else if(logicOp == "&&"){
        string lNext = newLabel();
        string lTrue = newLabel();
        string lFalse = newLabel();
        string lEnd = newLabel();

        visit(ctx->rel_expression(0));
        emitInstruction("CMP EAX, 0", line);
        emitInstruction("JNE " + lNext);
        emitInstruction("JMP " + lFalse);

        emitLabel(lNext);
        visit(ctx->rel_expression(1));
        emitInstruction("CMP EAX, 0");
        emitInstruction("JNE " + lTrue);
        emitInstruction("JMP " + lFalse);

        emitLabel(lTrue);
        emitInstruction("MOV EAX, 1", line);
        emitInstruction("JMP " + lEnd);

        emitLabel(lFalse);
        emitInstruction("MOV EAX, 0");

        emitLabel(lEnd);
    }
    return std::any();
}

antlrcpp::Any ICGVisitor::visitRelExprSimple(CSubsetParser::RelExprSimpleContext *ctx){
    visit(ctx->simple_expression());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitRelExprOp(CSubsetParser::RelExprOpContext *ctx){
    string relop = ctx->RELOP()->getText();
    int line = ctx->getStart()->getLine();

    visit(ctx->simple_expression(1));
    emitInstruction("PUSH EAX");

    visit(ctx->simple_expression(0));
    emitInstruction("POP EBX");
    emitInstruction("CMP EAX, EBX");

    string lTrue = newLabel();
    string lFalse = newLabel();
    string lEnd = newLabel();

    string jmpInst;
    if(relop == "<") jmpInst = "JL";
    else if(relop == "<=") jmpInst = "JLE";
    else if(relop == ">") jmpInst = "JG";
    else if(relop == ">=") jmpInst = "JGE";
    else if(relop == "==") jmpInst = "JE";
    else if(relop == "!=") jmpInst = "JNE";

    emitInstruction(jmpInst + " " + lTrue);
    emitInstruction("JMP " + lFalse);

    emitLabel(lTrue);
    emitInstruction("MOV EAX, 1", line);
    emitInstruction("JMP " + lEnd);

    emitLabel(lFalse);
    emitInstruction("MOV EAX, 0");

    emitLabel(lEnd);

    return std::any();
}

antlrcpp::Any ICGVisitor::visitSimpleExprTerm(CSubsetParser::SimpleExprTermContext *ctx){
    visit(ctx->term());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitSimpleExprAdd(CSubsetParser::SimpleExprAddContext *ctx){
    string op = ctx->ADDOP()->getText();
    int line = ctx->getStart()->getLine();

    visit(ctx->term());
    emitInstruction("PUSH EAX");

    visit(ctx->simple_expression());
    emitInstruction("POP EBX");

    if(op == "+"){
        emitInstruction("ADD EAX, EBX");
    } else if(op == "-"){
        emitInstruction("SUB EAX, EBX");
    }

    emitInstruction("PUSH EAX");
    emitInstruction("POP EAX", line);

    return std::any();
}

antlrcpp::Any ICGVisitor::visitTermUnary(CSubsetParser::TermUnaryContext *ctx){
    visit(ctx->unary_expression());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitTermMul(CSubsetParser::TermMulContext *ctx){
    string op = ctx->MULOP()->getText();
    int line = ctx->getStart()->getLine();

    visit(ctx->unary_expression());
    emitInstruction("PUSH EAX");

    visit(ctx->term());
    emitInstruction("POP EBX");

    if(op == "*"){
        emitInstruction("IMUL EBX");
        emitInstruction("PUSH EAX");
        emitInstruction("POP EAX", line);
    } else if(op == "/"){
        emitInstruction("CDQ");
        emitInstruction("IDIV EBX");
        emitInstruction("PUSH EAX");
        emitInstruction("POP EAX", line);
    } else if(op == "%"){
        emitInstruction("CDQ");
        emitInstruction("IDIV EBX");
        emitInstruction("MOV EAX, EDX");
        emitInstruction("PUSH EAX");
        emitInstruction("POP EAX", line);
    }

    return std::any();
}

antlrcpp::Any ICGVisitor::visitUnaryAdd(CSubsetParser::UnaryAddContext *ctx){
    string op = ctx->ADDOP()->getText();
    int line = ctx->getStart()->getLine();

    visit(ctx->unary_expression());

    if(op == "-"){
        emitInstruction("NEG EAX");
        emitInstruction("PUSH EAX");
        emitInstruction("POP EAX", line);
    }
    return std::any();
}

antlrcpp::Any ICGVisitor::visitUnaryNot(CSubsetParser::UnaryNotContext *ctx){
    int line = ctx->getStart()->getLine();
    visit(ctx->unary_expression());

    string lTrue = newLabel();
    string lEnd = newLabel();

    emitInstruction("CMP EAX, 0");
    emitInstruction("JNE " + lTrue);
    emitInstruction("MOV EAX, 1", line);
    emitInstruction("JMP " + lEnd);

    emitLabel(lTrue);
    emitInstruction("MOV EAX, 0");

    emitLabel(lEnd);

    return std::any();
}

antlrcpp::Any ICGVisitor::visitUnaryFactor(CSubsetParser::UnaryFactorContext *ctx){
    visit(ctx->factor());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFactorVar(CSubsetParser::FactorVarContext *ctx){
    visit(ctx->variable());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFactorFuncCall(CSubsetParser::FactorFuncCallContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFactorParen(CSubsetParser::FactorParenContext *ctx){
    visit(ctx->expression());
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFactorConstInt(CSubsetParser::FactorConstIntContext *ctx){
    string val = ctx->CONST_INT()->getText();
    int line = ctx->getStart()->getLine();
    emitInstruction("MOV EAX, " + val, line);
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFactorConstFloat(CSubsetParser::FactorConstFloatContext *ctx){
    string val = ctx->CONST_FLOAT()->getText();
    int line = ctx->getStart()->getLine();
    emitInstruction("MOV EAX, " + val, line);
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFactorInc(CSubsetParser::FactorIncContext *ctx){
    string varName = ctx->variable()->getText();
    SymbolInfo* sym = symbolTable.lookUp(varName);
    int line = ctx->getStart()->getLine();
    if(sym != nullptr){
        emitInstruction("MOV EAX, " + sym->getAsmOperand(), line);
        emitInstruction("PUSH EAX");
        emitInstruction("INC EAX");
        emitInstruction("MOV " + sym->getAsmOperand() + ", EAX");
        emitInstruction("POP EAX");
    }
    return std::any();
}

antlrcpp::Any ICGVisitor::visitFactorDec(CSubsetParser::FactorDecContext *ctx){
    string varName = ctx->variable()->getText();
    SymbolInfo* sym = symbolTable.lookUp(varName);
    int line = ctx->getStart()->getLine();
    if(sym != nullptr){
        emitInstruction("MOV EAX, " + sym->getAsmOperand(), line);
        emitInstruction("PUSH EAX");
        emitInstruction("DEC EAX");
        emitInstruction("MOV " + sym->getAsmOperand() + ", EAX");
        emitInstruction("POP EAX");
    }
    return std::any();
}

antlrcpp::Any ICGVisitor::visitArgListArgs(CSubsetParser::ArgListArgsContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitArgListEmpty(CSubsetParser::ArgListEmptyContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitArgsSingle(CSubsetParser::ArgsSingleContext *ctx){
    return std::any();
}

antlrcpp::Any ICGVisitor::visitArgsMultiple(CSubsetParser::ArgsMultipleContext *ctx){
    return std::any();
}
